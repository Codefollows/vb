CKEDITOR.plugins.setLang( 'simpleuploads', 'hu',
    {
        addFile : 'Fájl hozzáadása',
        addImage: 'Kép hozzáadása',
        processing: 'Feldolgozás...',
        fileTooBig : 'A fájl túl nagy, használjon kisebb méretű fájlt.',
        invalidExtension : 'Érvénytelen fájltípus, kizárólag érvényes fájlokat használjon.',
        nonAcceptedExtension: 'A fájltípus nem érvényes, kizárólag érvényes fájlokat használjon:\r\n%0',
		// The file isn't an accepted type for images
		nonImageExtension: 'You must select an image',

		// The width of the image is over the allowed maximum
		imageTooWide: 'The image is too wide',

		// The height of the image is over the allowed maximum
		imageTooTall: 'The image is too tall'
    }
);
